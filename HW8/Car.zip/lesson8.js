{
  
    var car={
         companyName: "",
         brand:"",
         engineSize:0,
         color:"",
         seats:0,

         toStr:function(){
             var str="company: "+ this.companyName+
                    " Brand: "+ this.brand+
                    " Engine: "+ this.engineSize+
                    " color: "+this.color+
                    " seats: "+this.seats;

            document.getElementById("output").innerHTML=str;
            console.log(str);
         }
    };

    function setCar(){
        var cn;
        var brnd;
        var es;
        var clor;
        var sts;

        cn=submitCompanyName();
        if(cn===null){
            return;
        }

        brnd=submitBrand();
        if(brnd===null){
            return;
        }

        es=submitEngine();
        if(es<0){
            return;
        }

        clor=submitCarColor();
        if(clor===null){
            return;
        }

        sts=submitSeats();

        car.companyName=cn;
        car.brand=brnd;
        car.engineSize=es;
        car.color=clor;
        car.seats=sts;

        car.toStr();

    }

    function submitCompanyName(){
        var companyName= document.getElementById("companyName").value;

        if(companyName.length>=2){
            return companyName;
        }
        alert("Company name should be at least 2 chars long");
        return null;
    }

    function submitBrand(){
        var brand=document.getElementById("brand").value;

        if(brand.length>=2){
            return brand;
        }
        alert("Brand name should be at least 2 chars long");
        return null;
    }

    function submitEngine(){
        var engineSize=parseInt(document.getElementById("engineSize").value);

        if( engineSize>=800 && engineSize<=6000 ){
            return engineSize;
        }
        alert("Engine size should be in range [800-6000]");
        return -1;
    }

    function submitCarColor(){
        var color=null;
        var counter=0;

        if(document.getElementById("red").checked){
            color="red";
            counter++;
        }

        if(document.getElementById("blue").checked){
            if(counter>0){
                alert("Car may have only one color");
                return null;
            }
            color="blue";
            counter++;
        }

        if(document.getElementById("green").checked){
            if(counter>0){
                alert("Car may have only one color");
                return null;
            }
            color="green";
            counter++;
        }

        if(document.getElementById("yellow").checked){
            if(counter>0){
                alert("Car may have only one color");
                return null;
            }
            color="yellow";
            counter++;
        }
        
        if(counter===0){
            alert("Car has a color");
            return null;
        }

        return color;
    }

    function submitSeats(){
        var seats=document.getElementById("seats").value;
        return seats;
    }
}