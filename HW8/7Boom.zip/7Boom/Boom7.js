{
    function boom7(){
        var i=0;
        var isBoom=false;

        while(i<=100){
            isBoom=boom(i);

            if(isBoom){
                // document.getElementById("output").innerHTML=" Boom " ;
                console.log(" Boom ");
            }else{
                // document.getElementById("output").innerHTML=" "+i+" ";
                console.log(i);
            }
            i++;
        }

    }  

    function boom(x){


        if((x%10===7 || x/10===7)|| x%7===0){
            return true;
        }
        return false;
    }
}