{
    var s1="a";


    var i1=s1.indexOf("a");
    var i2=s1.indexOf("b");

    alert(i1);
    alert(i2);
}