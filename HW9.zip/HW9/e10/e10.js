{

    function insert(num){
        if(num==='C'){
            document.getElementById("textview").value='';
            
        }else if(num==='='){
            document.getElementById("textview").value=eval(document.getElementById("textview").value);
        }else{
            document.getElementById("textview").value+=num;
        }
    }


   
}