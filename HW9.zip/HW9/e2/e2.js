{
    function randNumber(lower,upper){
        return Math.floor( Math.random()*(upper-(lower)+1) )+(lower);
    }

    function buttonA(){
        document.getElementById("screen").innerHTML=randNumber(1,1000);
    }

    function reverseString(str){
        var rStr="";
        var length=str.length;
        for(i=length-1;i>=0;i--){
            rStr+=str.charAt(i);
        }
        return rStr;
    }

    function buttonB(){
        var str;

        str=document.getElementById("textArea").value;
        str=reverseString(str);
        document.getElementById("textArea").value=str;

    }
}