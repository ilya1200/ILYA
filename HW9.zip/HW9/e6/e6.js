{
    /*
        Returns true if string polindrome.
    */
   function isPolindrome(str){
        return recIsPolindrome(str);
    }


    /*
        Returns true if string polindrome.
    */
    function recIsPolindrome(str){
        var leftChar;
        var rightChar;
        var isPol=false;

    
        if(str.length<2){
            return true;
        }

        leftChar=str.charAt(0);
        rightChar=str.charAt(str.length-1);
        isPol=(leftChar===rightChar)&&( recIsPolindrome(str.substring(1,str.length-1)) );
        return isPol;
    }


}