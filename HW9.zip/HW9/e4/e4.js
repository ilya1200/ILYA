{
    function randNumber(lower,upper){
        return Math.floor( Math.random()*(upper-(lower)+1) )+(lower);
    }

    function generateNumber(){
        return randNumber(-10000,10000);
    }
 
    function mainFunc(){
        var number;
        var maxPositive=0;

        while((number=generateNumber())>=0){    
            if(number>maxPositive){
                maxPositive=number;
            }
        }
        return maxPositive;
    }
}