{
  function insertionSort(arr){
    var str="";

    for(var j=1;j<arr.length && arr.length>1;j++){
        var key=arr[j];
        var i=j-1;
        while(i>=0 && arr[i]>key){
            arr[i+1]=arr[i];
            i-=1;
        }
        arr[i+1]=key;
    }

    for(var k=0;k<arr.length;k++){
        str+=arr[k];
    }
    return str;
  }

  function toCharArray(str){
      var arr=[];

      for(var i=0;i<str.length;i++){
          arr.push(str.charAt(i));
      }
      
      return arr;
  }

  function mySort(str){
    var resStr=  insertionSort(toCharArray(str));
    str=resStr;
    
    return str;
  }

}