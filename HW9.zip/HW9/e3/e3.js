{
    function countDigits(number){
        var cnt=0;

        while(number!=0){
            number=parseInt(number/10);
            cnt++;
        }
        return cnt;
    }
}