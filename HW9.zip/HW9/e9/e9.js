{
    function deleteDigits(str){
        var resultStr="";
        var nextChar;

        for(var i=0;i<str.length;i++){
            nextChar=str.charAt(i);
            if(!(nextChar>='0' && nextChar<='9')){
                resultStr+=nextChar;
            }
        }
        str=resultStr;
    }
}