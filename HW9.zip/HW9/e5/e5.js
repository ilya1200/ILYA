{
    function insertSpace(word){
        var i;
        var spacedWord="";
        var currentChar;

        for(i=0;i<word.length;i++){
            currentChar=word.charAt(i);
            if(currentChar===' '){
                return null;
            }else if(currentChar>='A' && currentChar<='Z'){
                spacedWord+=  " "+currentChar;
            }else{
                spacedWord+= currentChar;
            }
        }
    }
}