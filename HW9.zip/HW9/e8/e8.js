{
    function strstr(str1,str2){
        var count=0;
        var haystack=0;
        var needle=0;

        while(haystack<str1.length){
            if(str1.charAt(haystack)===str2.charAt(needle)){
                var h=haystack;
                var n=needle;
                while(n<str2.length && h<str1.length && str1.charAt(h)===str2.charAt(n)){
                    h++;
                    n++;
                }
                if(n===str2.length){
                    count++;
                }
            }
            haystack++;
        }
        return count;
    }
    

    function main_func(str1,str2){
        var cnt;
        if(str1.length<=str2.length){
            cnt=strstr(str2,str1);
        }else{
            cnt=strstr(str1,str2);
        }
        alert(cnt);
    }
}