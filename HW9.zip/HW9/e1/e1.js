{
    function numbersFrom50To380(){
        var str="";
 
        for(var cur=50;cur<=380;cur+=2){
            str+= cur+" ";
        }
        
        return str;
    }
}